//TURNING AN IMAGE INTO BLACK ND WHITE
#include<stdio.h>
#include<stdlib.h>

int main()
{
    FILE *image=fopen("image.bmp","rb");
    if(image==NULL)
        exit(0);
    unsigned char header[54],colortable[1024];
    int i;

    for(i=0;i<54;i++)
        header[i]=getc(image);

    int image_width=*(int*)&header[18];
    int image_height=*(int*)&header[22];
    int bit_depth=*(int*)&header[28];

    if(bit_depth<=8)
        fread(colortable,sizeof(unsigned char),1024,image);

    unsigned char pixel_information[image_width*image_height];
    fread(pixel_information,sizeof(unsigned char),(image_width*image_height),image);

    for(i=0;i<(image_width*image_height);i++)
        pixel_information[i]=(pixel_information[i]>127)?255:0;

    FILE *black_n_white=fopen("B&W IMAGE.bmp","wb");
    fwrite(header,sizeof(unsigned char),54,black_n_white);

    if(bit_depth<=8)
        fwrite(colortable,sizeof(unsigned char),1024,black_n_white);

    fwrite(pixel_information,sizeof(unsigned char),(image_width*image_height),black_n_white);
    fclose(image);
    fclose(black_n_white);
}
