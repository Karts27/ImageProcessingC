//DARKENING AN IMAGE
#include<stdio.h>
#include<stdlib.h>
#define DARKENING_FACTOR 50

int main()
{
    FILE *image=fopen("image.bmp","rb");
    if(image==NULL) exit(0);
    unsigned char header[54],colortable[1024];
    int i;
    for(i=0;i<54;i++)
        header[i]=getc(image);

    int image_width=*(int*)&header[18];
    int image_height=*(int*)&header[22];
    int bit_depth=*(int*)&header[28];

    if(bit_depth<=8)
        fread(colortable,sizeof(unsigned char),1024,image);

    unsigned char pixel_information[image_width*image_height];
    fread(pixel_information,sizeof(unsigned char),(image_width*image_height),image);

    for(i=0;i<(image_width*image_height);i++)
    {
        pixel_information[i]=pixel_information[i]-DARKENING_FACTOR;                      //DARKENING MEANS REDUCING THE PIXEL VALUE
        if(pixel_information[i]<0) pixel_information[i]=0;
    }

    FILE *dark_image=fopen("DARK IMAGE.bmp","wb");
    fwrite(header,sizeof(unsigned char),54,dark_image);

    if(bit_depth<=8)
        fwrite(colortable,sizeof(unsigned char),1024,dark_image);

    fwrite(pixel_information,sizeof(unsigned char),(image_width*image_height),dark_image);
    fclose(image);
    fclose(dark_image);
}

