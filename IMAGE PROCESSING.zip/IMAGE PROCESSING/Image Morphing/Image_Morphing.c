//IMAGE MORPHING IS DONE TO COMBINE TO IMAGES
#include<stdio.h>
#include<stdlib.h>

int main()
{
    FILE *image=fopen("image.bmp","rb");
    unsigned char header[54],color_table[1024];
    fread(header,sizeof(unsigned char),54,image);
    int image_width=*(int*)&header[18];
    int image_height=*(int*)&header[22];
    int bit_depth=*(int*)&header[28];

    if(bit_depth<=8)
        fread(color_table,sizeof(unsigned char),1024,image);

    unsigned char pixel_information [image_width*image_height];
    fread(pixel_information,sizeof(unsigned char),(image_width*image_height),image);
    FILE *image2=fopen("DARK IMAGE.bmp","rb");
    unsigned char header2[54],color_table2[1024];
    fread(header2,sizeof(unsigned char),54,image2);
    int image_width2=*(int*)&header2[18];
    int image_height2=*(int*)&header2[22];
    int bit_depth2=*(int*)&header2[28];

    if(bit_depth2<=8)
        fread(color_table2,sizeof(unsigned char),1024,image2);

    unsigned char pixel_information2[image_width2*image_height2];
    fread(pixel_information2,sizeof(unsigned char),(image_width2*image_height2),image2);
    unsigned char pixel_information3[image_width*image_height];
    int i;
    for(i=0;i<image_height*image_width;i++)
    {
        pixel_information3[i]=pixel_information[i]+pixel_information2[i];
        if(pixel_information3[i]>255) pixel_information3[i]=255;                      //THIS PROCESS IS CALLED SATURATION ALTHOUGH IT LOSES IMAGE INFORMATION
        //IN THIS CASE THE PIXEL VALUES HAD TO BE SCALED DOWN BEFORE ADDITION WHICH REQUIRES STUDY OF CONTRAST
    }
    FILE *image3=fopen("sum_image.bmp","wb");
    fwrite(header,sizeof(unsigned char),54,image3);
    if(bit_depth<=8) fwrite(color_table,sizeof(unsigned char),1024,image3);
    fwrite(pixel_information3,sizeof(unsigned char),(image_height*image_width),image3);
    fclose(image);
    fclose(image2);
    fclose(image3);
}
