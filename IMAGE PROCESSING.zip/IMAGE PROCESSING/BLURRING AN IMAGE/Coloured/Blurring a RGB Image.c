//BLURRING A RGB IMAGE
#include<stdio.h>
#include<stdlib.h>

int main()
{
    FILE *image =fopen("image.bmp","rb");
    unsigned char header[54],color_table[1024];
    fread(header,sizeof(unsigned char),54,image);
    int image_width=*(int*)&header[18];
    int image_height=*(int*)&header[22];
    int bit_depth=*(int*)&header[28];
    if(bit_depth<=8)
        fread(color_table,sizeof(unsigned char),1024,image);

    unsigned char pixel_information[image_width*image_height][3],new_pixel_information[image_width*image_height][3];
    int i,j;
    for(i=0;i<image_height*image_width;i++)
	{
		new_pixel_information[i][2]=pixel_information[i][2]=getc(image);					// blue
		new_pixel_information[i][1]=pixel_information[i][1]=getc(image);					// green
		new_pixel_information[i][0]=pixel_information[i][0]=getc(image);					// red
	}
	float v=1.0 / 9.0;
	float kernel[3][3]={{v,v,v},                        // initialize the blurrring kernel
						{v,v,v},
						{v,v,v}};
    int x,y;
    for(x=1;x<image_height-1;x++)
	{
		for(y=1;y<image_width-1;y++)
		{
			float sum0= 0.0;
			float sum1= 0.0;
			float sum2= 0.0;
			for(i=-1;i<=1;++i)
			{
				for(j=-1;j<=1;++j)
				{
					// matrix multiplication with kernel with every color plane
					sum0=sum0+kernel[i+1][j+1]*pixel_information[(x+i)*image_width+(y+j)][0];
					sum1=sum1+kernel[i+1][j+1]*pixel_information[(x+i)*image_width+(y+j)][1];
					sum2=sum2+kernel[i+1][j+1]*pixel_information[(x+i)*image_width+(y+j)][2];
				}
			}
			new_pixel_information[(x)*image_width+(y)][0]=sum0;
			new_pixel_information[(x)*image_width+(y)][1]=sum1;
			new_pixel_information[(x)*image_width+(y)][2]=sum2;
		}
	}
    FILE *blurred_rgb=fopen("BLURRED RGB.bmp","wb");
    fwrite(header,sizeof(unsigned char),54,blurred_rgb);
    if(bit_depth<=8) fwrite(color_table,sizeof(unsigned char),1024,blurred_rgb);
    for(i=0;i<image_height*image_width;i++)						//write image data back to the file
	{
		putc(new_pixel_information[i][2],blurred_rgb);
		putc(new_pixel_information[i][1],blurred_rgb);
		putc(new_pixel_information[i][0],blurred_rgb);
	}
    fclose(image);
    fclose(blurred_rgb);
}
