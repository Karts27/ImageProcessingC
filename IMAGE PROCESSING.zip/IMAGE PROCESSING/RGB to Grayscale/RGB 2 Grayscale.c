//CONVERTING RGB TO GRAYSCALE
#include<stdio.h>
#include<stdlib.h>

int main()
{
    FILE *image=fopen("image.bmp","rb");
    unsigned char header[54],color_table[1024];
    fread(header,sizeof(unsigned char),54,image);
    int image_width=*(int*)&header[18];
    int image_height=*(int*)&header[22];
    int bit_depth=*(int*)&header[28];
    if(bit_depth<=8) fread(color_table,sizeof(unsigned char),1024,image);
    FILE* grayscale=fopen("grayscale.bmp","wb");
    fwrite(header,sizeof(unsigned char),54,grayscale);
    if(bit_depth<=8) fwrite(color_table,sizeof(unsigned char),1024,grayscale);
    unsigned char pixel_information[image_height*image_width][3];
    int i,grayscale_value;
    for(i=0;i<image_height*image_width;i++)
    {
        pixel_information[i][2]=getc(image);
        pixel_information[i][1]=getc(image);
        pixel_information[i][0]=getc(image);
        grayscale_value=(pixel_information[i][0]*0.3)+(pixel_information[i][1]*0.59)+(pixel_information[i][2]*0.11);          //CONVERSION FORMULA
        putc(grayscale_value,grayscale);
		putc(grayscale_value,grayscale);
		putc(grayscale_value,grayscale);
    }
    fclose(image);
    fclose(grayscale);
    printf ("a");
}
