//CHANGE DETECTION
#include<stdio.h>
#include<stdlib.h>

int main()
{
    FILE *image=fopen("image.bmp","rb");
    unsigned char header[54],color_table[1024];
    fread(header,sizeof(unsigned char),54,image);
    int image_width=*(int*)&header[18];
    int image_height=*(int*)&header[22];
    int bit_depth=*(int*)&header[28];

    if(bit_depth<=8)
        fread(color_table,sizeof(unsigned char),1024,image);

    unsigned char pixel_information [image_width*image_height];
    fread(pixel_information,sizeof(unsigned char),(image_width*image_height),image);
    FILE *image2=fopen("Blurred Image.bmp","rb");

    unsigned char header2[54],color_table2[1024];
    fread(header2,sizeof(unsigned char),54,image2);

    int image_width2=*(int*)&header2[18];
    int image_height2=*(int*)&header2[22];
    int bit_depth2=*(int*)&header2[28];

    if(bit_depth2<=8)
        fread(color_table2,sizeof(unsigned char),1024,image2);

    unsigned char pixel_information2[image_width2*image_height2];
    fread(pixel_information2,sizeof(unsigned char),(image_width2*image_height2),image2);
    FILE *image3=fopen("copy_image.bmp","rb");
    unsigned char header3[54],color_table3[1024];
    fread(header3,sizeof(unsigned char),54,image3);
    int image_width3=*(int*)&header3[18];
    int image_height3=*(int*)&header3[22];
    int bit_depth3=*(int*)&header3[28];

    if(bit_depth3<=8)
        fread(color_table3,sizeof(unsigned char),1024,image3);

    unsigned char pixel_information3[image_width3*image_height3];
    fread(pixel_information3,sizeof(unsigned char),(image_width3*image_height3),image3);
    int i;
    float cnt=0,cnt1=0;

    for(i=0;i<image_height*image_width;i++)
    {
        int c =pixel_information2[i]-pixel_information[i];
        if(c==0) cnt++;
        int d =pixel_information3[i]-pixel_information[i];
        if(d==0) cnt1++;
    }

    int size=image_height*image_width;
    float similarity1=(cnt*100)/size;
    float similarity2=(cnt1*100)/size;
    float deviation1=100-similarity1;
    float deviation2=100-similarity2;
    printf("DEVIATION OBSERVED FROM BLURRED IMAGE  ::  %f\n\n",deviation1);
    printf("DEVIATION OBSERVED FROM IMAGE COPY  ::  %f\n\n",deviation2);
    fclose(image);
    fclose(image2);
    fclose(image3);
}
