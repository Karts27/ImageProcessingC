//NEGATIVE OF AN IMAGE
#include<stdio.h>
#include<stdlib.h>

int main()
{
    FILE *image=fopen("image.bmp","rb");
    if(image==NULL)
        exit(0);

    unsigned char header[54],colortable[1024];
    int i;
    for(i=0;i<54;i++)
        header[i]=getc(image);

    int image_width=*(int*)&header[18];
    int image_height=*(int*)&header[22];
    int bit_depth=*(int*)&header[28];

    if(bit_depth<=8)
        fread(colortable,sizeof(unsigned char),1024,image);

    unsigned char pixel_information[image_width*image_height];
    fread(pixel_information,sizeof(unsigned char),(image_width*image_height),image);

    FILE *negative=fopen("Negative_of_Image.bmp","wb");
    fwrite(header,sizeof(unsigned char),54,negative);

    if(bit_depth<=8)
        fwrite(colortable,sizeof(unsigned char),1024,negative);

    for(i=0;i<(image_width*image_height);i++)
        pixel_information[i]=255-pixel_information[i];        //Negative means new pixel data = 255-old pixel data

    fwrite(pixel_information,sizeof(unsigned char),(image_width*image_height),negative);
    fclose(image);
    fclose(negative);
}
