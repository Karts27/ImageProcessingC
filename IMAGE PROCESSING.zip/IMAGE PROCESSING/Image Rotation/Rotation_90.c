//90 degree rotation
#include<stdio.h>
#include<stdlib.h>

int main()
{
    FILE *image=fopen("image.bmp","rb");
    unsigned char header[54],colortable[1024];
    fread(header,sizeof(unsigned char),54,image);
    int image_width=*(int*)&header[18];
    int image_height=*(int*)&header[22];
    int bit_depth=*(int*)&header[28];

    if(bit_depth<=8)
        fread(colortable,sizeof(unsigned char),1024,image);

    unsigned char pixel_information[image_width][image_height];
    fread(pixel_information,sizeof(unsigned char),(image_height*image_width),image);
    FILE *rotate=fopen("90_rotate.bmp","wb");
    fwrite(header,sizeof(unsigned char),54,rotate);

    if(bit_depth<=8)
        fwrite(colortable,sizeof(unsigned char),1024,rotate);

    unsigned char pixel_information2[image_height][image_width];
    int x,y;
    for(x=0;x<image_height/2;x++)
    {
        for(y=x;y<image_height-x-1;y++)
        {
            pixel_information2[x][y]=pixel_information[y][image_height-x-1];
            pixel_information2[y][image_height-x-1]=pixel_information[image_height-x-1][image_height-y-1];
            pixel_information2[image_height-x-1][image_height-y-1]=pixel_information[image_height-y-1][x];
            pixel_information2[image_height-y-1][x]=pixel_information[x][y];
        }
    }

    fwrite(pixel_information2,sizeof(unsigned char),(image_height*image_width),rotate);
    fclose(image);
    fclose(rotate);
}
