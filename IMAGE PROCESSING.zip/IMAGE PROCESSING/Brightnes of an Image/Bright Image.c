//INCREASING THE BRIGHTNESS OF AN IMAGE
#include<stdio.h>
#include<stdlib.h>
#define BRIGHTNESS_FACTOR 50

int main()
{
    FILE *image=fopen("image.bmp","rb");
    if(image==NULL) exit(0);
    unsigned char header[54],colortable[1024];
    int i;
    for(i=0;i<54;i++)
        header[i]=getc(image);

    int image_width=*(int*)&header[18];
    int image_height=*(int*)&header[22];
    int bit_depth=*(int*)&header[28];

    if(bit_depth<=8)
        fread(colortable,sizeof(unsigned char),1024,image);

    unsigned char pixel_information[image_width*image_height];
    fread(pixel_information,sizeof(unsigned char),(image_width*image_height),image);

    for(i=0;i<(image_width*image_height);i++)
    {
        pixel_information[i]=pixel_information[i]+BRIGHTNESS_FACTOR;                      //INCREASING BRIGHTNESS MEANS INCREASING PIXEL VALUE
        if(pixel_information[i]>255)
            pixel_information[i]=255;
    }
    FILE *bright_image=fopen("BRIGHT IMAGE.bmp","wb");
    fwrite(header,sizeof(unsigned char),54,bright_image);

    if(bit_depth<=8)
        fwrite(colortable,sizeof(unsigned char),1024,bright_image);

    fwrite(pixel_information,sizeof(unsigned char),(image_width*image_height),bright_image);
    fclose(image);
    fclose(bright_image);
}
